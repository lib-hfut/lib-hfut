
radius = 25 
area = 3.1415 * radius * radius
print(area)
print("{:.2f}".format(area))
